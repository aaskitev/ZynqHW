src/platform.o src/platform.o: ../src/platform.c \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters.h \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters_ps.h \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xil_cache.h \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xil_types.h \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters.h \
 ../src/platform_config.h
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters.h:
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters_ps.h:
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xil_cache.h:
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xil_types.h:
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters.h:
../src/platform_config.h:
