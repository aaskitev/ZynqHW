src/helloworld.o src/helloworld.o: ../src/helloworld.c ../src/platform.h \
 ../src/platform_config.h \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xil_printf.h \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xil_types.h \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters.h \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters_ps.h \
 D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/bspconfig.h
../src/platform.h:
../src/platform_config.h:
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xil_printf.h:
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xil_types.h:
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters.h:
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/xparameters_ps.h:
D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/sw/Z_system_wrapper/standalone_domain/bspinclude/include/bspconfig.h:
