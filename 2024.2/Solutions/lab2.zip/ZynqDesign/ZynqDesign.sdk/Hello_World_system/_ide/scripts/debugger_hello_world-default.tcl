# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: D:\ZynqHW\2023.1\ZynqDesign\ZynqDesign.sdk\Hello_World_system\_ide\scripts\debugger_hello_world-default.tcl
# 
# 
# Usage with xsct:
# In an external shell use the below command and launch symbol server.
# symbol_server.bat -S -s tcp::1534
# To debug using xsct, launch xsct and run below command
# source D:\ZynqHW\2023.1\ZynqDesign\ZynqDesign.sdk\Hello_World_system\_ide\scripts\debugger_hello_world-default.tcl
# 
connect -path [list tcp::1534 tcp:192.168.215.122:60215]
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Digilent Zed 210248686883" && level==0 && jtag_device_ctx=="jsn-Zed-210248686883-23727093-0"}
fpga -file D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Hello_World/_ide/bitstream/Z_system_wrapper.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Z_system_wrapper/export/Z_system_wrapper/hw/Z_system_wrapper.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Hello_World/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk/Hello_World/Debug/Hello_World.elf
configparams force-mem-access 0
targets -set -nocase -filter {name =~ "*A9*#0"}
con
