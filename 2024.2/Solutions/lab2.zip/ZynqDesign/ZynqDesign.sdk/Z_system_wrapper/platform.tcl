# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct D:\ZynqHW\2023.1\ZynqDesign\ZynqDesign.sdk\Z_system_wrapper\platform.tcl
# 
# OR launch xsct and run below command.
# source D:\ZynqHW\2023.1\ZynqDesign\ZynqDesign.sdk\Z_system_wrapper\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {Z_system_wrapper}\
-hw {D:\ZynqHW\2023.1\ZynqDesign\Z_system_wrapper.xsa}\
-proc {ps7_cortexa9_0} -os {standalone} -out {D:/ZynqHW/2023.1/ZynqDesign/ZynqDesign.sdk}

platform write
platform generate -domains 
platform active {Z_system_wrapper}
platform config -updatehw {D:/ZynqHW/2023.1/ZynqDesign/Z_system_wrapper.xsa}
platform generate
platform config -updatehw {D:/ZynqHW/2023.1/ZynqDesign/Z_system_wrapper.xsa}
bsp reload
bsp reload
domain active {zynq_fsbl}
bsp reload
domain active {standalone_domain}
bsp reload
platform generate -domains 
platform clean
platform clean
platform generate
